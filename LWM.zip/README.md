# LWM (Learn With Me) - 100% Offline Private AI Platform

**LWM** is a high-performance, 100% offline private local AI workspace created by **Niranjan Kumar K** (KNI-ORG). It executes Large Language Models (LLMs) locally on your machine with complete privacy, high speed (46+ tokens/sec), and zero cloud API dependencies.

---

## 🚀 Quick Command Line Install & Launch

Open Terminal or Command Prompt and run:

```bash
curl https://kni1514.github.io/app/lwm.exe > lwm.exe && lwm
```

---

## 🌟 Key Platform Features

- **100% Offline Compute**: All model execution takes place directly on your local hardware with total data privacy.
- **Direct Installer Executable**: Single-click installation with custom brand icon, Start Menu shortcuts, and zero configuration required.
- **Hugging Face Live Hub Search**: Search any model repository directly from Hugging Face Hub with 1-click download & auto-configuration.
- **Top Curated Model Suite**: Pre-configured open AI models (#1 Phi-4 Mini 3.8B, #2 Llama 3.1 8B, #3 Mistral 7B, #4 Gemma 2 9B, #5 Hermes 3 8B, #6 DeepSeek Coder 6.7B).
- **Resumable HTTP Downloads**: Incomplete model downloads resume from exact byte offsets without corrupting model files.
- **Cancel Download Control**: Stop or cancel active downloads instantly from the user interface.
- **3D Rotating Voice Orb**: Interactive voice sphere with local speech-to-text dictation.

---

## 👤 About the Author

- **Architect**: Niranjan Kumar K (KNI-ORG)
- **Innovations**: Creator of the **K Programming Language** & Architect of **KNI OS**
- **Email**: `hackerenvironment1514@gmail.com`
- **WhatsApp / Phone**: `+91 9515888385`
- **Official Web Portal**: [https://kni1514.github.io/app/](https://kni1514.github.io/app/)
