LWM Assets Directory
