# About the Author & Lead Architect

**LWM (Learn With Me)** is designed and engineered by **Niranjan Kumar K**.

---

## 👤 Architect Profile

- **Creator & Lead Engineer**: Niranjan Kumar K (KNI-ORG)
- **Innovations**: Creator of the **K Programming Language** & Architect of **KNI OS**
- **Focus**: High-performance system software, native compilers, client-side AI compute engines, and secure offline applications.

---

## 📬 Contact & Support Channels

- **Email**: `hackerenvironment1514@gmail.com`
- **WhatsApp / Phone**: `+91 9515888385`
- **Official Website**: [https://kni1514.github.io/app/](https://kni1514.github.io/app/)
- **GitHub**: [https://github.com/kni1514/](https://github.com/kni1514/)
